package com.example.moneyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class ConvertActivity extends AppCompatActivity {
    private EditText mTxtMoney;
    private Spinner mSpinFrom, mSpinTo;
    private TextView txtTitle, mTextResult;
    private Button btnDoConvert, btnHistory;
    private String title, resultConvert, toSpinner;
    private List<RssFeedModel> mFeedModelList;
    private int getNumber, resultAfterConverted = 0;
    private static final String FILE_NAME = "history.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convert);

        title = getIntent().getStringExtra("cur");
        mTextResult = (TextView) findViewById(R.id.txtResult);
        mSpinFrom = (Spinner) findViewById(R.id.spinFrom);
        mSpinTo = (Spinner) findViewById(R.id.spinTo);
        txtTitle = (TextView) findViewById(R.id.txtConvertTitle);
        btnDoConvert = (Button) findViewById(R.id.btnDoConvert);
        btnHistory = (Button) findViewById(R.id.btnHistory);
        mTxtMoney = (EditText) findViewById(R.id.txtMoney);
        txtTitle.setText("Bảng chuyển đổi của " + title);
        //Set adapter for spin from
        ArrayList<String> items = new ArrayList<>();
        items.add(title);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        mSpinFrom.setAdapter(adapter1);
        mSpinFrom.setEnabled(false);

        //Set adapter for Spinner To.
        if (title != null) {
            int pos = adapter1.getPosition(title);
            mSpinFrom.setSelection(pos);
            //Create adapter
            RequestQueue queue = Volley.newRequestQueue(this);
            String url = "https://aud.fxexchangerate.com/rss.xml";

            // Request a string response from the provided URL.
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                List<String> countries = new ArrayList<>();
                                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                                DocumentBuilder builder = factory.newDocumentBuilder();

                                Document document = builder.parse(new InputSource(new StringReader(response)));
                                document.getDocumentElement().normalize();

                                NodeList list = document.getElementsByTagName("item");
                                for (int i = 0; i < list.getLength(); i++) {
                                    Node node = list.item(i);
                                    if (node.getNodeType() == Node.ELEMENT_NODE) {
                                        Element element = (Element) node;
                                        String code = element.getElementsByTagName("title").item(0).getTextContent();
                                        code = code.substring(code.lastIndexOf('(') + 1, code.lastIndexOf(')'));
                                        if(!code.equals(title)) {
                                            countries.add(code);
                                        }
                                    }
                                }
                                ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, countries);
                                mSpinTo.setAdapter(adapter);

                            } catch (Exception e) {
                                Log.v("Line 96", e.toString());
                            }

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            });
            queue.add(stringRequest);
        }
        btnDoConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toSpinner = mSpinTo.getSelectedItem().toString();
                if(mTxtMoney.getText().toString().isEmpty()) {
                    getNumber = 0;
                } else {
                    getNumber = Integer.parseInt(mTxtMoney.getText().toString());
                    new FetchFeedTask().execute((Void) null);

                }

            }
        });

        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ConvertActivity.this, HistoryActivity.class);
                startActivity(intent);
                save(view);
            }
        });
    }


    private class FetchFeedTask extends AsyncTask<Void, Void, Boolean> {
        private String urlLink;

        @Override
        protected void onPreExecute() {
            urlLink = "https://" + toSpinner.toLowerCase() + ".fxexchangerate.com/" + title.toLowerCase() + ".xml";
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            if (TextUtils.isEmpty(urlLink)) return false;
            try {
                if (!urlLink.startsWith("http://") && !urlLink.startsWith("https://"))
                    urlLink = "http://" + urlLink;
                URL url = new URL(urlLink);
                InputStream inputStream = url.openConnection().getInputStream();
                mFeedModelList = parseFeed(inputStream);

                return true;
            } catch (IOException e) {
                Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
            } catch (XmlPullParserException e) {
                Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {

                String[] splitParts = resultConvert.split(" ");
                String number = splitParts[24];
                resultAfterConverted = getNumber * Integer.parseInt(number.split("\\.", 2)[0]);
                mTextResult.setText(String.valueOf(resultAfterConverted) + " " + toSpinner);
            } else {
                Toast.makeText(ConvertActivity.this, "Enter a valid Rss feed url", Toast.LENGTH_LONG).show();
            }
        }
    }

    public List<RssFeedModel> parseFeed(InputStream inputStream) throws XmlPullParserException, IOException {
        boolean isItem = false;
        List<RssFeedModel> items = new ArrayList<>();
        try {
            XmlPullParser xmlPullParser = Xml.newPullParser();
            xmlPullParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            xmlPullParser.setInput(inputStream, null);     //xmlPullParser.nextTag();
            while (xmlPullParser.next() != XmlPullParser.END_DOCUMENT) {
                int eventType = xmlPullParser.getEventType();
                String name = xmlPullParser.getName();
                if (name == null) continue;
                if (eventType == XmlPullParser.END_TAG) {
                    if (name.equalsIgnoreCase("item")) {
                        isItem = false;
                    }
                    continue;
                }
                if (eventType == XmlPullParser.START_TAG) {
                    if (name.equalsIgnoreCase("item")) {
                        isItem = true;
                        continue;
                    }
                }
                Log.d("MyXmlParser", "Parsing name ==> " + name);
                String result = "";
                if (xmlPullParser.next() == XmlPullParser.TEXT) {
                    result = xmlPullParser.getText();
                    xmlPullParser.nextTag();
                }
                if (name.equalsIgnoreCase("description")) {
                    resultConvert = result;
                }

            }
        } finally {
            inputStream.close();
        }
        return items;
    }
    public void save(View v) {
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
        String strDate = dateFormat.format(date);
        String text = "\n" + Integer.toString(getNumber) + " " + title + " - " + Integer.toString(resultAfterConverted) + " " + toSpinner + " " + strDate + "\n" ;

        FileOutputStream fos = null;
        Toast.makeText(this, "Saved to " + text + "/" + FILE_NAME,
                Toast.LENGTH_LONG).show();
        try {
            fos = openFileOutput(FILE_NAME, MODE_APPEND);

            fos.write(text.getBytes());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}