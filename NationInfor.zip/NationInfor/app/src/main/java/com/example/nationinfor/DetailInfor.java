package com.example.nationinfor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailInfor extends AppCompatActivity {

    TextView txtName, txtPopulation, txtArea, txtCapital;
    ImageView image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_infor);

        txtName = (TextView) findViewById(R.id.name);
        txtPopulation = (TextView) findViewById(R.id.population);
        txtArea = (TextView) findViewById(R.id.area);
        txtCapital = (TextView) findViewById(R.id.capital);
        image = (ImageView) findViewById(R.id.image);

        Intent intent = getIntent();
        String countryCode = intent.getStringExtra("countryCode");
        String countryName = intent.getStringExtra("countryName");
        String population = intent.getStringExtra("population");
        String areaInSqKm = intent.getStringExtra("areaInSqKm");
        String capital = intent.getStringExtra("capital");

        txtName.setText(countryName);
        txtPopulation.setText("Population: "+population);
        txtArea.setText("Area: "+areaInSqKm+" km2");
        txtCapital.setText("Capital: "+capital);
        String url = "http://img.geonames.org/img/country/250/"+countryCode+".png";
        Picasso.get()
                .load(url)
                .into(image);
    }
}