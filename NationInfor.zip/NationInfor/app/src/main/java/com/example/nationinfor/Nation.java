package com.example.nationinfor;

public class Nation {
    String countryCode;
    String countryName;
    long population;
    double areaInSqKm;
    String capital;

    public Nation(String countryCode, String countryName, long population, double areaInSqKm, String capital) {
        this.countryCode = countryCode;
        this.countryName = countryName;
        this.population = population;
        this.areaInSqKm = areaInSqKm;
        this.capital = capital;
    }

    @Override
    public String toString() {
        return "Nation{" +
                "countryCode='" + countryCode + '\'' +
                ", countryName='" + countryName + '\'' +
                ", population=" + population +
                ", areaInSqKm=" + areaInSqKm +
                ", capital='" + capital + '\'' +
                '}';
    }
}
