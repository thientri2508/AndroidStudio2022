package com.example.nationinfor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Nation> nations;
    private RequestQueue mQueue;
    ListView numbersListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numbersListView = findViewById(R.id.listView);
        nations = new ArrayList<>();
        mQueue = Volley.newRequestQueue(this);
        jsonParse();

    }

    private void jsonParse(){
        String url = "http://api.geonames.org/countryInfoJSON?username=caoth";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("geonames");
                            for(int i=0; i<jsonArray.length();i++){
                                JSONObject geonames = jsonArray.getJSONObject(i);
                                String countryCode = geonames.getString("countryCode");
                                String countryName = geonames.getString("countryName");
                                String population = geonames.getString("population");
                                String areaInSqKm = geonames.getString("areaInSqKm");
                                String capital = geonames.getString("capital");
                                Nation nation = new Nation(countryCode, countryName, Long.parseLong(population), Double.parseDouble(areaInSqKm), capital);
                                nations.add(nation);
                            }
                            NumbersViewAdapter numbersViewAdapter = new NumbersViewAdapter(MainActivity.this, nations);
                            numbersListView.setAdapter(numbersViewAdapter);
                            numbersListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                    Nation n = nations.get(i);
                                    Intent intent = new Intent(MainActivity.this, DetailInfor.class);
                                    intent.putExtra("countryCode", n.countryCode);
                                    intent.putExtra("countryName", n.countryName);
                                    Locale localeEN = new Locale("en", "EN");
                                    NumberFormat en = NumberFormat.getInstance(localeEN);
                                    intent.putExtra("population", en.format(n.population));
                                    intent.putExtra("areaInSqKm", String.format("%, .2f",n.areaInSqKm));
                                    intent.putExtra("capital", n.capital);
                                    startActivity(intent);
                                }
                            });
                        } catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);

    }
}